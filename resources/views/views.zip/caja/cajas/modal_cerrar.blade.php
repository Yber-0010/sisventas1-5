<div class="modal fade modal-slide-in-rigth" aria-hidden="true" role="dialog" tabindex="-1" id="modal_cerrar">
   
    <div class="modal-dialog">
       <div class="modal-content">
           <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-Label="Close">
              <span aria-hidden="true">x</span>
              </button>
              <h4 class="modal-title">Cerrar Caja</h4>
           </div>
           <div class="modal-body">
              <p>Confirme si desea cerrar la caja</p>
           </div>
           <div class="modal-footer">
             <button type="button" class="btn btn-default" data-dismiss="modal">Atras</button>
             <button type="submit" class="btn btn-primary" id="count_click" name="count_click">Confirmar</button>
             
           </div>
       </div>
    </div>
 
  </div>